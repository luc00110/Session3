package TP2;

import java.sql.Connection;
import java.sql.SQLException;

public class Functions {

	private Connection co;
	
	// Tables
	public Culture Culture;
	public DemandeMembreLot DemandeMembreLot;
	public Lot Lot;
	public Membre Membre;
	public LotMembre LotMembre;
	public Plante Plante;
	
	public Functions(Connection connect) throws SQLException {
		this.co = connect;
		this.Culture = new Culture(connect);
		this.DemandeMembreLot = new DemandeMembreLot(connect);
		this.Lot = new Lot(connect);
		this.Membre = new Membre(connect);
		this.LotMembre = new LotMembre(connect);
		this.Plante = new Plante(connect);
		
		System.out.println("\n\nInitialisation Compl�t�e. "
						   + "\n========================="
						   + "\n�tat 0 := Noice\n�tat 1 := It did fkup\n�tat +1 := more than 1 fkup\n\n");
	}
	
	public void showAll() throws SQLException {
		Culture.showTable();
		DemandeMembreLot.showTable();
		Lot.showTable();
		Membre.showTable();
		LotMembre.showTable();
		Plante.showTable();
		}
	
	// R01
	public int inscrireMembre(String nom, String prenom, String noMembre, String motDePasse) throws SQLException {
		int state = Membre.inscrireMembre(nom, prenom, motDePasse, noMembre);
		System.out.println("\nR01, �tat Inscrire Membre : " + state + "\n");
		return state;
	}
	
	
	// R02
	public int supprimerMembre(String noMembre) throws SQLException {
		int state = Membre.supprimerMembre(noMembre);
		System.out.println("\nR02, �tat Supprimer Membre : " + state + "\n");
		return state;
	}
	
	// R03
	public int promouvoirAdministrateur(String noMembre) throws SQLException {
		int state = Membre.promouvoirAdministrateur(noMembre);
		System.out.println("\nR03, �tat Promouvoir Administrateur : " + state + "\n");
		return state;
	}
	
	// R04
	public int ajouterLot(String nomLot, int nbMaxMembre) throws SQLException {
		int state = Lot.ajouterLot(nomLot, nbMaxMembre);
		System.out.println("\nR04, �tat Ajouter Lot : " + state + "\n");
		return state;
	}
	
	// R05
	public int supprimerLot(String nomLot) throws SQLException {
		int state = 0; // 0 car on y ajoute les erreurs soudjacentes
		state += Lot.supprimerLot(nomLot);
		state += LotMembre.supprimerLot(nomLot);
		state += DemandeMembreLot.supprimerLot(nomLot);
		System.out.println("\nR05, �tat Supprimer Lot : " + state + "\n");
		return state;
	}
	
	// R06
	public int rejoindreLot(String nomLot, String noMembre) throws SQLException {
		int state = DemandeMembreLot.rejoindreLot(nomLot, noMembre);
		System.out.println("\nR06, �tat Rejoindre Lot : " + state + "\n");
		return state;
	}
	
	// R07
	public int accepterDemande(String nomLot, String noMembre) throws SQLException {
		int state = 0;
		state += LotMembre.ajouterTuple(nomLot, noMembre);
		state += DemandeMembreLot.supprimerDemande(nomLot, noMembre);
		System.out.println("\nR07, �tat Accepter Demande : " + state + "\n");
		return state;
	}
	
	// R08
	public int refuserDemande(String nomLot, String noMembre) throws SQLException {
		int state = DemandeMembreLot.supprimerDemande(nomLot, noMembre);
		System.out.println("\nR08, �tat Refuser Demande : " + state + "\n");
		return state;
	}
	
	// R09
	public int ajouterPlante(String nomPlante, int tempsCulture) throws SQLException {
		int state = Plante.ajouterPlante(nomPlante, tempsCulture);
		System.out.println("\nR09, �tat Ajouter Plante : " + state + "\n");
		return state;
	}
	
	// R10
	public int retirerPlante(String nomPlante) throws SQLException {
		int state = Plante.retirerPlante(nomPlante);
		System.out.println("\nR08, �tat Retirer Plante : " + state + "\n");
		return state;
	}
}
