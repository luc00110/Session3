package TP2;

import java.sql.Connection;
import java.sql.SQLException;

public class MembreLot extends Table {

	public MembreLot(Connection beepboop) throws SQLException {
		super(beepboop);
	}


}
