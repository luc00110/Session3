package TP2;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class MembreLot extends Table {

	public MembreLot(Connection beepboop) throws SQLException {
		super(beepboop);
	}

	// R05
	public int supprimerLot(String nomLot) throws SQLException {
    	int state = 1;
    	PreparedStatement ps = con.prepareStatement("DELETE FROM Lot WHERE nomLot = ?");
    	int affectedRows = 0;
    	
    	try {
    	    ps.setString(1, nomLot);
    	    affectedRows = ps.executeUpdate();
            con.commit();
            ps.close();
    	    state = 0;
    	} catch(Exception e) {
    	    System.out.println("I was already deleted. Let me introduce myself...");    	    
    	}
    	if (affectedRows != 1) {
    	    state = 1;
    	}
    	System.out.println("SypprimerLot state :" + state);
    	return state;
    }
	
}
