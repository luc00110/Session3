package TP2;

import java.sql.Connection;
import java.sql.SQLException;

public class Plante extends Table {

	public Plante(Connection beepboop) throws SQLException {
		super(beepboop);
	}

}
