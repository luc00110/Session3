package TP2;

import java.sql.Connection;
import java.sql.SQLException;

public class Lot extends Table {

	public Lot(Connection beepboop) throws SQLException {
		super(beepboop);
	}
}
