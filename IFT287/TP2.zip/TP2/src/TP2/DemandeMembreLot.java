package TP2;

import java.sql.Connection;
import java.sql.SQLException;

public class DemandeMembreLot extends Table {

	public DemandeMembreLot(Connection beepboop) throws SQLException {
		super(beepboop);
	}

}
