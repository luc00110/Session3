package TP2;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Culture extends Table {

	public Culture(Connection beepboop) throws SQLException {
		super(beepboop);
	}

	public void showTable() throws SQLException
    {
        Statement s = con.createStatement();
        String query = "SELECT * FROM Culture";
        ResultSet rSet = s.executeQuery(query);
        System.out.println("\nCulture :\n| nomPlante | nomLot | noMembre | nbExemplaires | datePlantation |\n"
        				  +"=================================================================");
        while (rSet.next()) {
            String nomPlante = rSet.getString("nomPlante");
            String nomLot = rSet.getString("nomLot");
            String noMembre = rSet.getString("noMembre");
            String nbExemplaires = rSet.getString("nbExemplaires");
            String datePlantation = rSet.getString("datePlantation");
            
            System.out.println("| "+nomPlante+" | "+nomLot+" | "+noMembre+" | "+nbExemplaires+" | "+datePlantation+" |");
        }
        System.out.println("");
    }
}
