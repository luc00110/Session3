package TP2;

import java.sql.Connection;
import java.sql.SQLException;

public class Culture extends Table {

	public Culture(Connection beepboop) throws SQLException {
		super(beepboop);
	}


}
