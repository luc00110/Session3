package TP2;

import java.sql.Connection;
import java.sql.SQLException;

public class Culture extends Table {

	public Culture(Connection beepboop) throws SQLException {
		super(beepboop);
	}

	@Override
	public void showTable() throws SQLException {
		
	}

	@Override
	public int deleteRow(int row) {
		return 0;
	}

}
