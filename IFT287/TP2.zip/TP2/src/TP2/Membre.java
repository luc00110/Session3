package TP2;

import java.sql.*;
import java.sql.SQLException;

public class Membre extends Table
{

    //private Connexion con;
    
    public Membre(Connection beepboop) throws SQLException
    {
        super(beepboop);
        //con = beepboop;
    }

    public void showTable() throws SQLException
    {
        Statement s = con.createStatement();
        String query = "SELECT * FROM MEMBRE";
        ResultSet rSet = s.executeQuery(query);
        System.out.println("MEMBRE :\n | nomember | nom | prenom | motdepasse | admin |\n"
        				  +"===========================================================\n");
        while (rSet.next()) {
            String nomembre = rSet.getString("nomembre");
            String nom = rSet.getString("nom");
            String prenom = rSet.getString("prenom");
            String mdp = rSet.getString("motdepasse");
            boolean admin = rSet.getBoolean("admin");
            
            System.out.println("\n | "+nomembre+" | "+nom+" | "+prenom+" | "+mdp+" | "+admin+" |");
            
        }
        
    }

    // R01
    public int inscrireMembre(String prenom, String nom, String motdepasse, String nomembre) throws SQLException
    {
    	int state = 1;
    	
    	PreparedStatement ps = con.prepareStatement("INSERT INTO Membre(nom, prenom, noMembre, motDePasse) VALUES\r\n" + 
    			"  (?,?,?,?,?)");
    	ps.setString(1, nom);
    	ps.setString(2, prenom);
    	ps.setString(3, nomembre);
    	ps.setString(4, motdepasse);
    	
    	int affectedRows = ps.executeUpdate();
    	
    	// code d'erreur
    	if (affectedRows > 0) {
    		state = 0;
    		
            con.commit();
            ps.close();
            
    	}
    	System.out.println("Insert Into Member State : " + state);
        return state;
    }
    
    //R02  
    public int supprimerMembre(String nomembre) throws SQLException {
    	int state = 1;
    	PreparedStatement ps = con.prepareStatement("DELETE FROM Membre WHERE nomembre = ?");
    	int affectedRows = 0;
    	
    	try {
    	    ps.setString(1, nomembre);
    	    affectedRows = ps.executeUpdate();
            con.commit();
            ps.close();
    	    state = 0;
    	} catch(Exception e) {
    	    System.out.println("I was already deleted. Let me introduce myself...");    	    
    	}
    	if (affectedRows != 1) {
    	    state = 1;
    	}
    	System.out.println("Delete From Membre State : " + state);
    	return state;
    }
    	
}
