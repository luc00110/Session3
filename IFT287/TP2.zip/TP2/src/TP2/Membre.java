package TP2;

import java.sql.*;
import java.sql.SQLException;

public class Membre extends Table
{

    //private Connexion con;
    
    public Membre(Connection beepboop) throws SQLException
    {
        super(beepboop);
        //con = beepboop;
    }

    public void showTable() throws SQLException
    {
        Statement s = con.createStatement();
        String query = "SELECT * FROM MEMBRE";
        ResultSet rSet = s.executeQuery(query);
        System.out.println("MEMBRE :\n | nomember | nom | prenom | motdepasse | admin |\n"
        				  +"===========================================================\n");
        while (rSet.next()) {
            String nomembre = rSet.getString("nomembre");
            String nom = rSet.getString("nom");
            String prenom = rSet.getString("prenom");
            String mdp = rSet.getString("motdepasse");
            boolean admin = rSet.getBoolean("admin");
            
            System.out.println("\n | "+nomembre+" | "+nom+" | "+prenom+" | "+mdp+" | "+admin+" |");
            
        }
        
    }

    // R01
    public int inscrireMembre(String prenom, String nom, String motdepasse, String nomembre, boolean admin) throws SQLException
    {
    	int state = 1;
    	

    	PreparedStatement ps = con.prepareStatement("INSERT INTO Membre(nom, prenom, noMembre, motDePasse, admin) VALUES\r\n" + 
    			"  (?,?,?,?,?)");
    	ps.setString(1, nom);
    	ps.setString(2, prenom);
    	ps.setString(3, nomembre);
    	ps.setString(4, motdepasse);
    	ps.setBoolean(5, admin);
    	
    	int affectedRows = ps.executeUpdate();
    	
    	// code d'erreur
    	if (affectedRows > 0) {
    		state = 0;
    	}
    	System.out.println("ERROR STATE : " + state);
        return state;
    }
    
    public void deleteLucien() throws SQLException {
    	
    	Statement s = con.createStatement();
    	
    	String query = "DELETE FROM Membre WHERE nomembre = 6942069";
    	
    	ResultSet rSet = s.executeQuery(query);
    	
    	while (rSet.next()) {
            String nomembre = rSet.getString("nomembre");
            String nom = rSet.getString("nom");
            String prenom = rSet.getString("prenom");
            String mdp = rSet.getString("motdepasse");
            boolean admin = rSet.getBoolean("admin");
            
            System.out.println("\n | "+nomembre+" | "+nom+" | "+prenom+" | "+mdp+" | "+admin+" |");
            
        }
    }


}
