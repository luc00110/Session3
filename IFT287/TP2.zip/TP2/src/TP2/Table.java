package TP2;

import java.sql.*;
import java.sql.SQLException;

public abstract class Table {

    protected Connection con;
    protected String name;
    
    public Table(Connection beepboop) throws SQLException
    {
        this.con = beepboop;
        
    }

}